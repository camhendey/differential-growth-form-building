# Differential Growth: extended technical presentation

Five coordinated A2 vector boards. The two original boards are retained, with three new technical companions.

- Growth_Evolution: seven preserved vector states and length measurements.
- Growth_Mechanics: matched local crops and the verified workflow.
- Growth_Physical_Mechanics: four competing mechanical goals and conceptual residuals.
- Growth_Natural_Principles: growth mismatch, tissue buckling and the model analogy.
- Growth_Control_Translation: exact field mappings, an analytical response graph and validation boundaries.

Growth_Sequence_Presentation.pdf combines all five boards. Each board has an editable SVG, a vector PDF with embedded fonts and 3 mm bleed, and a preview PNG. Technical_Notes.md contains the implementation explanation, scientific references, numerical example, evidence register and clearly identified future tests.

Original source paths are unchanged. New mechanics and tissue diagrams are original explanatory vector schematics; they are not replacement project geometry or measured physical simulations. No native Rhino/Kangaroo run was performed during this extension.

The original source assets, build scripts and geometry audit are preserved under reproduction/ and Original_Vector_Validation.json. See Original_README.md for the baseline reproduction steps; then follow Technical_Notes.md for the extension. Technical_Vector_Validation.json and Technical_Preflight.json record checks on the added boards.

Fonts: Nimbus Roman and DejaVu Sans. SVG is A2 trim size; PDF media size is 600 × 426 mm including bleed. PDFs use RGB artwork, without a printer-specific CMYK profile or PDF/X certification.
