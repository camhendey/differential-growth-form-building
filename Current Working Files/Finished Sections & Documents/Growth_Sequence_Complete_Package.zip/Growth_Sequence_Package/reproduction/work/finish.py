from pathlib import Path
from pypdf import PdfReader,PdfWriter,Transformation
from pypdf.generic import RectangleObject, DecodedStreamObject, NameObject
from pypdf import PageObject
from reportlab.pdfgen import canvas
import io,fitz,json,shutil,zipfile
R=Path(__file__).resolve().parent.parent; O=R/'output'; mm=72/25.4;b=3*mm;w=594*mm;h=420*mm
combined=PdfWriter();checks=[]
for name in ['Growth_Evolution','Growth_Mechanics']:
 original=PdfReader(O/(name+'.pdf'));p=original.pages[0]
 page=PageObject.create_blank_page(width=w+2*b,height=h+2*b)
 stream=DecodedStreamObject();stream.set_data(f'q {248/255} {246/255} {240/255} rg 0 0 {w+2*b} {h+2*b} re f Q'.encode());page[NameObject('/Contents')]=stream
 page.merge_transformed_page(p,Transformation().translate(b,b));page.trimbox=RectangleObject([b,b,b+w,b+h]);page.bleedbox=RectangleObject([0,0,w+2*b,h+2*b])
 writer=PdfWriter();writer.add_page(page);writer.add_metadata({'/Title':name.replace('_',' '),'/Subject':'A2 landscape, 3 mm bleed, original cubic vector geometry','/Creator':'Programmatic source-vector composition'});writer.write(O/(name+'.pdf'));combined.add_page(page)
 doc=fitz.open(O/(name+'.pdf'));pg=doc[0];assert not pg.get_images();curves=sum(item[0]=='c' for d in pg.get_drawings() for item in d['items'])
 expected=10500 if name=='Growth_Evolution' else 6000
 assert curves==expected,(name,curves,expected)
 for word in pg.get_text('words'):
  assert 0<=word[0]<word[2]<=pg.rect.width and 0<=word[1]<word[3]<=pg.rect.height
 pg.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(O/(name+'_Preview.png'))
 checks.append({'file':name+'.pdf','raster_images':0,'retained_cubic_commands':curves,'trim_mm':[594,420],'bleed_mm':3,'page_count':1,'text_within_page':True})
combined.add_metadata({'/Title':'Differential Growth | Evolution and Mechanics','/Subject':'Two A2 vector presentation boards, 3 mm bleed'});combined.write(O/'Growth_Sequence_Presentation.pdf')
p=O/'Vector_Validation.json';a=json.loads(p.read_text());a['pdf_preflight']=checks;p.write_text(json.dumps(a,indent=2))
