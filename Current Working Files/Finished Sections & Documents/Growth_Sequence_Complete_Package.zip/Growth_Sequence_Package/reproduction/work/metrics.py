import json,re,numpy as np
from pathlib import Path
s=json.loads(Path('work/vectors.json').read_text()); z,w=np.polynomial.legendre.leggauss(32);t=(z+1)/2
for a in s:
 d=a['paths'][1];tok=re.findall('[MLCZ]|-?\\d+(?:\\.\\d+)?',d);i=0;total=0;cur=None;start=None;n=0
 while i<len(tok):
  op=tok[i];i+=1
  if op=='M':cur=np.array(list(map(float,tok[i:i+2])));start=cur.copy();i+=2
  elif op=='C':
   p=np.array(list(map(float,tok[i:i+6]))).reshape(3,2);i+=6
   der=3*((1-t[:,None])**2*(p[0]-cur)+2*(1-t[:,None])*t[:,None]*(p[1]-p[0])+t[:,None]**2*(p[2]-p[1]));total+=np.dot(w,np.linalg.norm(der,axis=1))/2;cur=p[2];n+=1
  elif op=='L':
   p=np.array(list(map(float,tok[i:i+2])));i+=2;total+=np.linalg.norm(p-cur);cur=p
  elif op=='Z':total+=np.linalg.norm(cur-start)
 a['length_export_units']=float(total);a['cubic_segments']=n
for a in s:
 a['length_ratio_to_seed']=a['length_export_units']/s[0]['length_export_units'];print(a['file'],a['cubic_segments'],round(a['length_ratio_to_seed'],4))
print('boundary equality',len(set(a['paths'][0] for a in s)))
Path('work/vectors.json').write_text(json.dumps(s))
