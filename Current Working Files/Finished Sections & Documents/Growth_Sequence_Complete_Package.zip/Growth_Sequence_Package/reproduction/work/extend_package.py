from pathlib import Path
import json, math, html, re, shutil
from lxml import etree as ET
R=Path(__file__).resolve().parent.parent
O=R/'extended'; O.mkdir(exist_ok=True)
for n in ['Growth_Evolution','Growth_Mechanics']:
 for ext in ['svg','pdf']:
  src=R/'output'/(n+'.'+ext)
  if src.exists():shutil.copy2(src,O/src.name)
S=json.loads((R/'work/vectors.json').read_text())
BG='#f8f6f0'; INK='#36566a'; MUT='#627783'; RULE='#b6bfc0'; PALE='#e6ebea'; ACC='#a87551'
def e(s): return html.escape(str(s))
class Board:
 def __init__(self,title,sub,num):
  self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" width="594mm" height="420mm" viewBox="0 0 594 420"><title>{e(title)}</title><desc>Editable technical vector illustration. Source geometry and explanatory schematics are explicitly distinguished.</desc><rect width="594" height="420" fill="{BG}"/>']; self.num=num
  self.text(24,20,'D I F F E R E N T I A L   G R O W T H',3.1)
  self.text(570,20,f'PROCESS STUDY   /   {num:02}',2.8,anchor='end',sans=True); self.line(24,26,570,26)
  self.text(24,49,title,13); self.text(24,62,sub,3.5,sans=True,color=MUT)
 def text(self,x,y,t,size=3.3,color=INK,anchor='start',sans=False,italic=False):
  self.a.append(f'<text x="{x}" y="{y}" font-family="{ "DejaVu Sans" if sans else "Nimbus Roman"}" font-size="{size}" fill="{color}" text-anchor="{anchor}"'+(' font-style="italic"' if italic else '')+f'>{e(t)}</text>')
 def lines(self,x,y,ts,size=3.25,leading=5.25,color=MUT):
  for i,t in enumerate(ts):self.text(x,y+i*leading,t,size,color,sans=True)
 def math(self,x,y,markup,size=6):
  markup=markup.replace('<sub>','<tspan baseline-shift="sub" font-size="65%">').replace('</sub>','</tspan>').replace('<sup>','<tspan baseline-shift="super" font-size="65%">').replace('</sup>','</tspan>')
  self.a.append(f'<text x="{x}" y="{y}" font-family="Nimbus Roman" font-style="italic" font-size="{size}" fill="{INK}">{markup}</text>')
 def path(self,d,col=INK,sw=.45,fill='none',dash=None):
  self.a.append(f'<path d="{d}" fill="{fill}" stroke="{col}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
 def line(self,x,y,xx,yy,col=RULE,sw=.18,dash=None):self.path(f'M{x} {y} L{xx} {yy}',col,sw,dash=dash)
 def rect(self,x,y,w,h,fill='none',stroke=RULE,sw=.18):self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def circ(self,x,y,r=1.2,fill=INK,stroke='none',sw=.2):self.a.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def arrow(self,x,y,xx,yy,col=ACC,sw=.4):
  self.line(x,y,xx,yy,col,sw); ang=math.atan2(yy-y,xx-x); z=2.1
  self.path(f'M{xx-z*math.cos(ang-.48)} {yy-z*math.sin(ang-.48)} L{xx} {yy} L{xx-z*math.cos(ang+.48)} {yy-z*math.sin(ang+.48)}',col,sw)
 def tag(self,x,y,t):self.text(x,y,t,2.7,sans=True)
 def geom(self,i,x,y,size,ident,crop=None):
  W=425.1969
  if crop:
   xmin,ymin,xmax,ymax=crop; sc=size/(xmax-xmin);tx=x-xmin*sc;ty=y+ymax*sc
   self.a.append(f'<defs><clipPath id="clip-{ident}"><rect x="{x}" y="{y}" width="{size}" height="{size}"/></clipPath></defs><g clip-path="url(#clip-{ident})">')
  else:sc=size/W;tx=x;ty=y+size
  self.a.append(f'<g id="{ident}" data-source-file="{e(S[i]["file"])}" transform="translate({tx:.12f},{ty:.12f}) scale({sc:.12f},{-sc:.12f})" fill="none">')
  for j,d in enumerate(S[i]['paths']):self.a.append(f'<path d="{d}" stroke="{MUT if j==0 else INK}" stroke-width="{.18/sc:.12f}"/>')
  self.a.append('</g>')
  if crop:self.a.append('</g>')
 def footer(self,note):
  self.line(24,398,570,398);self.text(24,407,note,2.6,color=MUT,sans=True)
  self.text(570,407,f'GROWTH EVOLUTION   /   {self.num:02}',2.65,anchor='end',sans=True)
 def save(self,name): (O/(name+'.svg')).write_text('\n'.join(self.a+['</svg>']))

b=Board('The mechanics of a fold','Competing goals turn excess target length into a spatially constrained, folded curve.',3)
b.tag(24,82,'OBSERVED GEOMETRY  /  STATE 04')
b.geom(4,24,94,219,'physical-detail',crop=(0,212.59845,212.59845,425.1969))
b.rect(24,94,219,219)
b.text(24,326,'One curve. Four competing requirements.',6)
b.lines(24,337,['The form emerges from coupled constraints.','No single goal specifies the final pattern.','This crop retains the original exported Béziers.'],3.5,6)
b.line(255,79,255,364)
b.tag(270,82,'EXPLANATORY SCHEMATICS  /  NOT MEASURED FORCE VECTORS')
# length card
x=270;y=97
b.text(x,y,'01  /  Extension',5.2); b.tag(x,y+8,'LENGTH(LINE)')
b.line(x+25,y+34,x+88,y+34,INK,.65)
b.circ(x+25,y+34);b.circ(x+88,y+34)
b.arrow(x+21,y+34,x+6,y+34); b.arrow(x+92,y+34,x+107,y+34)
b.line(x+6,y+47,x+107,y+47,MUT,.25); b.line(x+6,y+44,x+6,y+50);b.line(x+107,y+44,x+107,y+50)
b.text(x+56,y+44,'target length ℓ*',3.6,anchor='middle',italic=True)
b.text(x,y+64,'eℓ = ℓ − ℓ*',5,italic=True)
b.lines(x,y+74,['If ℓ < ℓ*, the goal favours extension.','Other goals may prevent the target','from being reached.'],3.15,5)
# angle
x=427
b.text(x,y,'02  /  Bending',5.2);b.tag(x,y+8,'ANGLE')
b.path(f'M{x+8} {y+45} L{x+60} {y+25} L{x+111} {y+45}',INK,.65)
for xx,yy in [(8,45),(60,25),(111,45)]:b.circ(x+xx,y+yy)
b.path(f'M{x+44} {y+31} Q{x+60} {y+47} {x+76} {y+31}',ACC,.35)
b.text(x+60,y+44,'θ',4.5,anchor='middle',italic=True)
b.text(x,y+64,'eθ = θ − θ*',5,italic=True)
b.lines(x,y+74,['The angle goal resists departures','from its target. Lower weight permits','tighter turns under competing goals.'],3.15,5)
b.line(270,193,570,193)
# collider
x=270;y=212
b.text(x,y,'03  /  Exclusion',5.2);b.tag(x,y+8,'COLLIDER')
for yy in [28,47]:
 b.path(f'M{x+12} {y+yy} L{x+108} {y+yy}',PALE,22)
 b.line(x+12,y+yy,x+108,y+yy,INK,.55)
b.arrow(x+60,y+26,x+60,y+15); b.arrow(x+60,y+49,x+60,y+60)
b.line(x+91,y+28,x+91,y+47,ACC,.35)
b.text(x+98,y+40,'d',4,italic=True)
b.text(x,y+75,'δ = max(0, rᵢ + rⱼ − dᵢⱼ)',4.8,italic=True)
b.lines(x,y+85,['Thickened segments resist overlap.','Radii set an exclusion scale; strength','controls the influence of the goal.'],3.15,5)
# surface
x=427
b.text(x,y,'04  /  Confinement',5.2);b.tag(x,y+8,'ONMESH')
b.path(f'M{x+8} {y+52} L{x+83} {y+52} L{x+119} {y+28} L{x+45} {y+28} Z',RULE,.25,PALE)
for t in [.25,.5,.75]:b.line(x+8+75*t,y+52,x+45+74*t,y+28,RULE,.2)
b.line(x+26,y+40,x+101,y+40,RULE,.2)
b.circ(x+63,y+15);b.circ(x+63,y+40,1.2,BG,INK)
b.arrow(x+63,y+19,x+63,y+36)
b.text(x+73,y+24,'p',4,italic=True);b.text(x+73,y+45,'host mesh',3.2)
b.text(x,y+75,'eₘ = dist(p, M)',4.8,italic=True)
b.lines(x,y+85,['Points are pulled to the host mesh.','The host is prescribed: this system','does not grow the surface itself.'],3.15,5)
b.line(270,321,570,321)
b.lines(270,333,['Symbols describe geometric residuals, not the exact solver update.','Kangaroo balances weighted goals with momentum and damping.','Recorded states are numerical relaxation states, not biological time.'],3.25,5.5)
b.rect(24,367,546,19,PALE,PALE)
b.text(31,375,'WHY FOLDS EMERGE',2.8,sans=True)
b.text(31,382,'Extension competes with confinement, bending resistance and contact; deformation accommodates the mismatch.',3.5,sans=True)
b.footer('Definition-derived mechanism. Schematics are conceptual; source detail is unchanged. Technical notes: [D1].')
b.save('Growth_Physical_Mechanics')

b=Board('From living growth to a design system','A shared principle: incompatible preferred dimensions can generate form through mechanical constraint.',4)
b.tag(24,82,'BIOLOGICAL PRINCIPLE  /  ILLUSTRATIVE STRIP, NOT A SPECIES MODEL')
# top 3 sequence strips
for x,title,sub in [(24,'01  /  Unequal growth','Different regions acquire different preferred lengths.'),(212,'02  /  Compatibility','Connected tissue cannot freely adopt every local length.'),(400,'03  /  Buckling','Thin tissue can deform out of plane to release stress.')]:
 b.text(x,95,title,5.3);b.text(x,167,sub,3.05,sans=True,color=MUT)
# preferred lengths top/bottom
b.line(36,124,158,124,ACC,.9);b.line(52,145,142,145,INK,.9)
for xx in [36,158]:b.line(xx,120,xx,128,ACC,.4)
for xx in [52,142]:b.line(xx,141,xx,149,INK,.4)
b.text(166,126,'margin',3.1,color=ACC);b.text(150,148,'interior',3.1)
b.arrow(62,114,38,114);b.arrow(132,114,156,114)
b.rect(230,119,130,32,PALE,INK,.35)
b.line(230,119,360,119,ACC,.8)
for xx in range(240,360,10):b.line(xx,120,xx,150,RULE,.22)
b.arrow(230,109,253,109);b.arrow(360,109,337,109)
b.text(295,140,'constrained mismatch',3.4,anchor='middle')
# warped strip schematic vector surface
d='M413 146 C424 115 435 154 446 126 C457 103 468 150 479 124 C490 104 501 151 512 125 C523 111 535 141 550 123 L550 150 C507 150 458 150 413 163 Z'
b.path(d,INK,.35,PALE)
b.path('M413 146 C424 115 435 154 446 126 C457 103 468 150 479 124 C490 104 501 151 512 125 C523 111 535 141 550 123',ACC,.8)
b.a.append(f'<defs><clipPath id="tissue-strip"><path d="{d}"/></clipPath></defs><g clip-path="url(#tissue-strip)">')
for xx in range(423,546,12):b.line(xx,105,xx,164,RULE,.22)
b.a.append('</g>')
b.lines(24,181,['Wavy leaf and petal margins are documented examples. Research links differential tissue growth to residual stress and 3D form [R1, R2].'],3.2)
b.line(24,195,570,195)
b.tag(24,208,'TRANSLATING THE PRINCIPLE  /  WHAT IS SHARED, WHAT CHANGES')
columns=[24,185,365]
for xx,tt in zip(columns,['Physical concept','In living tissue','In this Grasshopper system']):b.text(xx,222,tt,4.8)
rows=[
 ('Preferred size','Local growth changes stress-free dimensions.','Length goals prescribe segment target lengths.'),
 ('Connected material','Adjacent tissue regions must remain compatible.','A connected chain couples neighbouring segments.'),
 ('Resistance to bending','Tissue thickness and stiffness resist curvature.','Angle goals bias turning; weights are design controls.'),
 ('Where form can move','A leaf or petal may buckle out of its initial plane.','Points remain on a prescribed host mesh.'),
 ('Spatial variation','Growth strain can vary across a tissue [R1].','Density assigns radius, length and bend strength.'),
]
for k,(a,c,d) in enumerate(rows):
 yy=234+k*22;b.line(24,yy-6,570,yy-6)
 b.text(24,yy+3,a,4.2)
 # carefully split fixed columns
 def wrap(t,limit):
  out=[];line=''
  for word in t.split():
   if len(line+' '+word)>limit:out.append(line);line=word
   else:line=(line+' '+word).strip()
  return out+[line]
 b.lines(185,yy+1,wrap(c,49),3.2,5.2)
 b.lines(365,yy+1,wrap(d,54),3.2,5.2)
b.line(24,338,570,338)
b.text(24,352,'A mechanical analogy, made controllable.',6.2)
b.lines(24,362,['The project abstracts incompatible length, bending and contact into a design system. It is not a calibrated model of tissue,','cell division or biological growth rate. Its 3D tests conform a curve to a host; they do not predict the host’s morphogenesis.'],3.4,5.8)
b.lines(24,384,['[R1] Huang et al., PNAS (2018), doi:10.1073/pnas.1811296115.   [R2] Sharon et al., Nature (2002), doi:10.1038/419579a.'],2.8,4.5)
b.footer('Original conceptual diagrams. Biological references support the analogy; no biological simulation is claimed.')
b.save('Growth_Natural_Principles')

b=Board('Turning a field into behaviour','The density control is a bounded translation from spatial intent to three local mechanical parameters.',5)
b.tag(24,82,'IMPLEMENTATION  /  EXACT PARAMETER MAPPING FROM THE EMBEDDED SCRIPT')
b.text(24,98,'Sample once. Assign. Relax.',6)
b.lines(24,111,['The field is sampled at initial segment midpoints.','Cyclic smoothing reduces jumps around the closed chain.','Assignments travel with the segments during relaxation.'],3.5,6)
b.rect(24,140,251,31,PALE,PALE)
b.math(32,152,'D<sub>i</sub> = C<sup>b fᵢ</sup>',7)
b.text(32,163,'fᵢ ∈ [−1, 1]   ·   C = contrast   ·   b = blend',3.4,sans=True)
b.lines(24,184,['Attractor distance and an axis gradient define the input field.','An attractor modifies the assignments; it is not a force pulling','the evolving curve toward a point. Reset after changing inputs.'],3.25,5.5)
# exact equations and key under each
b.math(304,98,'r<sub>i</sub> / r<sub>0</sub> = clamp(D<sub>i</sub><sup>−s</sup>, 0.3, 3.0)')
b.lines(304,108,['Spacing contrast s: smaller radii permit closer packing.'],3.15)
b.math(304,134,'ℓ<sub>i</sub>* / ℓ<sub>0</sub> = clamp(D<sub>i</sub><sup>g</sup>, 0.65, 1.5)')
b.lines(304,144,['Growth boost g: optional increase in target length.'],3.15)
b.math(304,170,'B<sub>j</sub> / B<sub>0</sub> = clamp(D̂<sub>j</sub><sup>−2q</sup>, 0.12, 6.0)')
b.lines(304,180,['Loop contrast q: lower strength allows tighter turning.','D̂ⱼ = √(Dᵢ Dpaired) uses both segments at the angle goal.'],3.15,5.5)
b.line(24,209,570,209)
b.tag(24,222,'ANALYTICAL RESPONSE  /  ILLUSTRATIVE INPUTS, NOT MEASURED RUN SETTINGS')
# exact response plot, log x and linear y, generated mathematical data only
x0=43;y0=310;pw=216;ph=65
def px(d):return x0+pw*(math.log(d,2)+1)/2
def py(v):return y0-ph*v/4
for v in range(5):b.line(x0,py(v),x0+pw,py(v));b.text(x0-5,py(v)+1,str(v),2.8,anchor='end',sans=True,color=MUT)
for d in [.5,1,2]:b.line(px(d),y0,px(d),y0-ph,RULE,.2,dash='1 1');b.text(px(d),y0+7,str(d),2.9,anchor='middle',sans=True)
b.text(24,237,'Multiplier relative to baseline',3.1,sans=True)
b.text(x0+pw/2,y0+15,'Density D (log scale)',3.1,anchor='middle',sans=True)
funcs=[(lambda d:d**-1,INK,None),(lambda d:d**-2,ACC,None),(lambda d:d**.25,MUT,'2 1')]
for fn,col,dash in funcs:
 ds=[2**(-1+2*i/160) for i in range(161)]
 b.path('M'+' L'.join(f'{px(d):.7f} {py(fn(d)):.7f}' for d in ds),col,.55,dash=dash)
for x,col,txt,dash in [(24,INK,'Radius',None),(100,ACC,'Bend strength',None),(203,MUT,'Length','2 1')]:
 b.line(x,338,x+9,338,col,.6,dash=dash);b.text(x+12,339,txt,3.0,sans=True)
b.lines(24,353,['Example: s = 1, q = 1, g = 0.25; adjacent segments share D.','If g = 0, target length stays unchanged as density varies.'],3.05,5.2)
# numeric table right
xx=[304,390,454,526]
for x,t in zip(xx,['Density D','r / r₀','ℓ* / ℓ₀','B / B₀']):b.text(x,242,t,4.1)
for k,d in enumerate([.5,1,2]):
 yy=257+17*k;b.line(304,yy-8,570,yy-8)
 for x,t in zip(xx,[f'{d:.1f}',f'{d**-1:.2f}',f'{d**.25:.2f}',f'{d**-2:.2f}']):b.text(x,yy,t,4.4)
b.line(304,301,570,301)
b.text(304,314,'A control law is not an outcome guarantee.',5.1)
b.lines(304,325,['Radius is not measured curve clearance; bending strength','is not a specified loop diameter. The response also depends','on target lengths, the host, discretization and solver state.'],3.2,5.5)
b.lines(304,353,['Export evidence: L₀₅ / L₀ = 24.39; L₀₆ / L₀ = 19.77.','The later curve is 18.94% shorter. More solver updates','cannot be read as monotonically increasing curve length.'],3.05,5.2)
b.rect(24,376,546,13,PALE,PALE)
b.text(31,384,'VALIDATION TARGETS   /   smooth-curve clearance  ·  host deviation  ·  goal residuals  ·  repeatability across resolution',3.15,sans=True)
b.footer('Equations and table checked against [D1]. Plot is analytical. Validation targets are future tests, not completed results.')
b.save('Growth_Control_Translation')

# Every placed project path must be exactly the source transcription.
checks=[]
for p in O.glob('Growth_*.svg'):
 root=ET.parse(str(p));ns={'s':'http://www.w3.org/2000/svg'}
 assert not root.findall('.//s:image',ns)
 count=0
 for g in root.findall('.//s:g',ns):
  src=g.get('data-source-file')
  if src:
   orig=next(t for t in S if t['file']==src)
   assert [a.get('d') for a in g.findall('s:path',ns)]==orig['paths'];count+=1
 checks.append({'file':p.name,'retained_source_groups':count,'source_paths_exact':True,'raster_elements':0})
(O/'Technical_Vector_Validation.json').write_text(json.dumps(checks,indent=2))
print('Built three technical boards; all project path strings preserved.')
