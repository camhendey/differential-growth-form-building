from pathlib import Path
import json, math
from pypdf import PdfReader, PdfWriter, PageObject, Transformation
from pypdf.generic import RectangleObject, DecodedStreamObject, NameObject
import fitz
R=Path(__file__).resolve().parent.parent;O=R/'extended'; mm=72/25.4
names=['Growth_Evolution','Growth_Mechanics','Growth_Physical_Mechanics','Growth_Natural_Principles','Growth_Control_Translation']
checks=[];combined=PdfWriter()
for i,name in enumerate(names):
 p=PdfReader(O/(name+'.pdf')).pages[0]
 if i>=2:
  w=594*mm;h=420*mm;bleed=3*mm
  page=PageObject.create_blank_page(width=w+2*bleed,height=h+2*bleed)
  stream=DecodedStreamObject();stream.set_data(f'q {248/255} {246/255} {240/255} rg 0 0 {w+2*bleed} {h+2*bleed} re f Q'.encode());page[NameObject('/Contents')]=stream
  page.merge_transformed_page(p,Transformation().translate(bleed,bleed))
  page.trimbox=RectangleObject([bleed,bleed,bleed+w,bleed+h]);page.bleedbox=RectangleObject([0,0,w+2*bleed,h+2*bleed])
  wr=PdfWriter();wr.add_page(page);wr.add_metadata({'/Title':name.replace('_',' '),'/Subject':'A2 technical vector board; 3 mm bleed'});wr.write(O/(name+'.pdf'));p=page
 combined.add_page(p)
 d=fitz.open(O/(name+'.pdf'));pg=d[0]
 assert len(pg.get_images())==0
 for word in pg.get_text('words'):assert 0<=word[0]<word[2]<=pg.rect.width and 0<=word[1]<word[3]<=pg.rect.height,(name,word)
 fonts=[]
 for f in pg.get_fonts(full=True):
  font=d.extract_font(f[0]);assert len(font[3])>0,(name,f);fonts.append(f[3])
 cubic=sum(item[0]=='c' for draw in pg.get_drawings() for item in draw['items'])
 if i==0:assert cubic==10500
 if i==1:assert cubic==6000
 if i==2:assert cubic>=1500
 pg.get_pixmap(matrix=fitz.Matrix(1.0,1.0),alpha=False).save(O/(name+'_Preview.png'))
 checks.append({'file':name+'.pdf','raster_images':0,'fonts_embedded':fonts,'cubic_commands':cubic,'trim_mm':[594,420],'bleed_mm':3,'all_text_inside_page':True})
combined.add_metadata({'/Title':'Differential Growth | Evolution, Mechanics and Natural Principles','/Subject':'Five coordinated A2 vector boards'});combined.write(O/'Growth_Sequence_Presentation.pdf')
# Independently check printed analytical response against the implemented clamps.
clamp=lambda x,a,b:max(a,min(b,x))
rows=[]
for den in [.5,1,2]:
 row=[den,clamp(den**-1,.3,3),clamp(den**.25,.65,1.5),clamp((math.sqrt(den*den))**-2,.12,6)]
 assert all(math.isfinite(v) for v in row);rows.append(row)
assert rows[1]==[1,1,1,1]
S=json.loads((R/'work/vectors.json').read_text());loss=100*(1-S[6]['length_export_units']/S[5]['length_export_units']);assert round(loss,2)==18.94
audit={'pdf_checks':checks,'response_rows_D_radius_length_bend':rows,'state05_to06_length_reduction_percent':loss,'biological_diagrams':'conceptual, not simulation','native_solver_executed':False}
(O/'Technical_Preflight.json').write_text(json.dumps(audit,indent=2))
print(json.dumps({'boards':5,'raster_images':0,'fonts':'embedded','response_table':'verified','length_reduction_percent':loss}))
