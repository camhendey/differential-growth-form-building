from pathlib import Path
import json,html,re,hashlib,csv,shutil
from lxml import etree as E
ROOT=Path(__file__).resolve().parent.parent
S=json.loads((ROOT/'work/vectors.json').read_text());OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
W=425.1969; BG='#f8f6f0';INK='#36566a';MUT='#627783';RULE='#b6bfc0';PALE='#e6ebea'
def esc(s):return html.escape(str(s))
class Board:
 def __init__(self,title,subtitle,num):
  self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="594mm" height="420mm" viewBox="0 0 594 420"><title>{esc(title)}</title><desc>Original Rhino AI cubic Bézier geometry retained. A2 landscape presentation.</desc><rect id="paper" width="594" height="420" fill="{BG}"/>']
  self.text(24,20,'D I F F E R E N T I A L   G R O W T H',3.1,spacing=0)
  self.text(570,20,f'PROCESS STUDY   /   {num:02}',2.8,anchor='end',sans=True)
  self.line(24,26,570,26)
  self.text(24,49,title,13)
  self.text(24,62,subtitle,3.6,sans=True,color=MUT)
 def text(self,x,y,t,size=3.3,color=INK,anchor='start',sans=False,italic=False,spacing=None):
  self.a.append(f'<text x="{x}" y="{y}" fill="{color}" font-family="{ "DejaVu Sans" if sans else "Nimbus Roman"}" font-size="{size}" text-anchor="{anchor}"'+(' font-style="italic"' if italic else '')+(f' letter-spacing="{spacing}"' if spacing else '')+f'>{esc(t)}</text>')
 def lines(self,x,y,lines,size=3.2,leading=5,color=MUT,sans=True):
  for k,t in enumerate(lines):self.text(x,y+k*leading,t,size,color=color,sans=sans)
 def line(self,x1,y1,x2,y2,color=RULE,width=.18,dash=None):
  self.a.append(f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{color}" stroke-width="{width}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
 def rect(self,x,y,w,h,fill='none',stroke=RULE,sw=.18):self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def geom(self,i,x,y,size,ident,crop=None):
  # All source coordinates remain verbatim; placement is a uniform affine transform.
  if crop:
   xmin,ymin,xmax,ymax=crop;s=size/(xmax-xmin)
   self.a.append(f'<defs><clipPath id="clip-{ident}"><rect x="{x}" y="{y}" width="{size}" height="{size}"/></clipPath></defs><g clip-path="url(#clip-{ident})">')
   tx=x-xmin*s;ty=y+ymax*s
  else:s=size/W;tx=x;ty=y+size
  self.a.append(f'<g id="{ident}" data-source-file="{esc(S[i]["file"])}" transform="translate({tx:.12f},{ty:.12f}) scale({s:.12f}, {-s:.12f})" fill="none" stroke-linecap="round" stroke-linejoin="round">')
  self.a.append(f'<path id="{ident}-boundary" d="{S[i]["paths"][0]}" stroke="{MUT}" stroke-width="{.15/s:.12f}"/>')
  self.a.append(f'<path id="{ident}-growth" d="{S[i]["paths"][1]}" stroke="{INK}" stroke-width="{.165/s:.12f}"/>')
  self.a.append('</g>')
  if crop:self.a.append('</g>')
 def footer(self,left,num):
  self.line(24,398,570,398)
  self.text(24,407,left,2.65,color=MUT,sans=True)
  self.text(570,407,f'GROWTH EVOLUTION   /   {num:02}',2.65,anchor='end',sans=True)
 def save(self,name):
  p=OUT/name;p.write_text('\n'.join(self.a+['</svg>']));return p
b=Board('Evolution of growth','Seven recorded states reveal the transition from a simple closed curve to a folded spatial pattern.',1)
labels=['Initial seed','First folds','Emergent folding','Expanding folds','Progressive growth','Domain occupation','Continued relaxation']
caps=[['A smooth closed curve establishes','the initial condition.'],['Small deformations appear in','four regions of the seed.'],['Distinct lobes extend towards','the corners of the domain.'],['Larger folds spread across','the available square.'],['Successive folds form a denser,','folded spatial pattern.'],['The curve occupies the domain','with pronounced local bands.'],['The longer-run state redistributes','the pattern across the square.']]
for i in range(7):
 row=i//4;col=i%4;x=24+141*col;y=83+159*row
 b.geom(i,x+6.5,y,110,f'state-{i:02}')
 b.text(x,y+123,f'{i:02}  /  {labels[i]}',4.5)
 b.lines(x,y+132,caps[i],3.05,4.6)
 b.text(x,y+148,f'L / L₀   {S[i]["length_ratio_to_seed"]:.2f}',2.85,sans=True,color=INK)
# final empty cell becomes interpretive text, aligned to geometric grid
x=447;y=258
b.text(x,y,'Reading the sequence',5.6)
b.line(x,y+6,x+123,y+6)
b.lines(x,y+16,['Growth first produces folds; later states','show continued geometric rearrangement.','The last export has a shorter curve than','state 05 despite its longer recorded run.'],3.2,5.4)
b.text(x,y+48,'ONE DOMAIN, SEVEN STATES',2.85,sans=True,spacing=.3)
b.lines(x,y+58,['All square boundaries are identical.','Every state uses the same drawing scale','and preserves its exported curve.'],3.2,5.4)
b.text(x,y+84,'L / L₀',4.2,italic=True)
b.lines(x,y+93,['Exported curve length relative to the seed.','A geometric measure, not elapsed time,','solver energy or percentage coverage.'],3.05,5)
b.footer('Recorded states are not equal time intervals. Length ratios are measured from the supplied Bézier exports.',1)
b.save('Growth_Evolution.svg')

b=Board('How the curve finds its form','Local geometry and the verified Grasshopper goals behind the recorded evolution.',2)
xs=[24,212,400];ids=[2,4,6]
for x,i,title,cap in zip(xs,ids,['Fold emergence','Fold accumulation','Pattern redistribution'],[['One lobe develops into a corner-facing fold.'],['Neighbouring folds pack into curved bands.'],['The later state rearranges the local pattern.']]):
 b.text(x,80,f'{i:02}  /  {title}',4.5)
 b.geom(i,x+7,89,152,f'detail-{i:02}',crop=(0,W/2,W/2,W))
 b.line(x+7,241,x+159,241,width=.14);b.line(x+159,89,x+159,241,width=.14)
 b.lines(x,252,cap,3.05,4.5)
# small locator uses actual source boundary and an annotation only
b.geom(0,24,263,16,'crop-locator')
b.rect(24,263,8,8,fill=PALE,stroke=INK,sw=.22)
b.lines(45,268,['Matched upper-left quadrants. Original curves are clipped and enlarged without reconstruction.'],3.05,4.5)
b.line(24,289,570,289)
# Compact topology: prepared seed -> four concurrent goals -> solver -> output, with a feedback arrow.
b.text(24,302,'THE COMPUTATIONAL MECHANISM',2.95,sans=True,spacing=.35)
# nodes in three conceptual columns plus output
b.text(24,319,'Prepare the seed',5)
b.lines(24,327,['Host-derived curve → rebuild → pull to surface.','Divide Curve + Shift List + Line establish','the segment chain before relaxation.'],3.05,5)
b.line(24,347,139,347)
b.text(24,357,'Density assignments',4.2)
b.lines(24,365,['Initial segment samples set local radius,','target length and bending strength.','Assignments travel with the segments.'],3.0,4.8)
# goals 2x2 compact
for x,y,title,desc in [(171,317,'Length(Line)',['Target lengths drive','segment expansion.']),(274,317,'Angle',['Bending goals influence','the shape of folds.']),(171,354,'Collider',['Thickened segments','resist local overlap.']),(274,354,'OnMesh',['Particles are constrained','to the host mesh.'])]:
 b.text(x,y,title,4.2);b.lines(x,y+8,desc,3.0,4.6)
# topology bus and arrow indicating jointly solved goals
b.line(148,338,161,338,INK,.25);b.line(158,336,161,338,INK,.25);b.line(158,340,161,338,INK,.25)
b.line(371,322,379,322,INK,.25);b.line(371,359,379,359,INK,.25);b.line(379,322,379,359,INK,.25)
b.line(379,340,391,340,INK,.25);b.line(388,338,391,340,INK,.25);b.line(388,342,391,340,INK,.25)
b.text(400,319,'Relax and reconstruct',5)
b.lines(400,327,['BouncySolver balances the connected goals','with momentum across repeated iterations.','A periodic NURBS curve forms the output.'],3.05,5)
b.line(400,349,570,349)
b.text(400,359,'Iteration changes the geometry',4.2)
b.lines(400,367,['The supplied chain pre-divides the seed.','It does not add new vertices each iteration.'],3.0,4.8)
b.footer('Mechanics verified from the supplied definition. Detail views illustrate observed form, not isolated force measurements.',2)
b.save('Growth_Mechanics.svg')
# Measured evidence; no model-unit assumptions.
with (OUT/'Growth_Measurements.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['state','label','source_file','cubic_bezier_segments','length_in_export_coordinates','length_relative_to_seed'])
 for i,s in enumerate(S):writer.writerow([f'{i:02}',labels[i],s['file'],s['cubic_segments'],f'{s["length_export_units"]:.8f}',f'{s["length_ratio_to_seed"]:.8f}'])
# Exact vector check on all paths, including retained hidden portions of detail crops.
audit=[]
for name in ['Growth_Evolution.svg','Growth_Mechanics.svg']:
 tree=E.parse(str(OUT/name));ns={'s':'http://www.w3.org/2000/svg'}
 assert not tree.findall('.//s:image',ns)
 for g in tree.findall('.//s:g',ns):
  src=g.get('data-source-file')
  if src:
   original=next(a for a in S if a['file']==src)
   paths=g.findall('s:path',ns)
   assert [p.get('d') for p in paths]==original['paths']
   audit.append({'svg':name,'group':g.get('id'),'source':src,'source_path_strings_exact':True})
(OUT/'Vector_Validation.json').write_text(json.dumps({'all_boundaries_identical':True,'curves_per_export':1,'cubic_segments_per_curve':1500,'geometry_paths_unmodified':audit,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'upload').iterdir()}},indent=2))
