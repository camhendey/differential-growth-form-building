from pathlib import Path
import re,json
files=sorted(Path('upload').glob('*.ai'),key=lambda p:int(re.search(r'(?:Stage|Step)0?(\d)',p.name)[1]))
S=[]
for i,p in enumerate(files):
 paths=[];cmd=[]
 for line in p.read_text().splitlines():
  tok=line.split()
  if not tok:continue
  op=tok[-1]
  if op in ['m','L','l','c','C'] and all(re.fullmatch(r'-?\d+(?:\.\d+)?',v) for v in tok[:-1]):
   cmd.append({'m':'M','l':'L','L':'L','c':'C','C':'C'}[op]+' '+' '.join(tok[:-1]))
  elif op in ['s','S'] and cmd:
   paths.append(' '.join(cmd)+(' Z' if op=='s' else ''));cmd=[]
 assert len(paths)==2,(p,len(paths))
 S.append({'file':p.name,'paths':paths})
Path('work/vectors.json').write_text(json.dumps(S))
a=['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="510" viewBox="0 0 1600 510"><rect width="1600" height="510" fill="#faf8f2"/>']
for i,s in enumerate(S):
 x=20+i*225
 a.append(f'<text x="{x}" y="30" font-size="20">{i:02}</text><g transform="translate({x},270) scale(.48,-.48)" fill="none" stroke="#35566b" stroke-width="1.2">')
 a.extend(f'<path d="{d}"/>' for d in s['paths']);a.append('</g>')
a.append('</svg>');Path('work/contact.svg').write_text(''.join(a))
