# Differential Growth: Evolution and Mechanics

Two coordinated A2 landscape boards document the supplied seven-state sequence and the computational mechanism behind it.

## Deliverables

- **Growth_Sequence_Presentation.pdf**: combined two-page presentation.
- **Growth_Evolution.svg / .pdf**: seven chronological states at identical scale, with descriptive captions and measured relative curve length.
- **Growth_Mechanics.svg / .pdf**: matched upper-left detail crops from states 02, 04 and 06, plus the verified preparation, goal and solver relationships.
- **Growth_Measurements.csv**: source-derived geometric measurements.
- **Vector_Validation.json**: source hashes, exact SVG path checks and PDF vector preflight.
- **Preview PNGs**: convenient review images only. The SVG and PDF artwork is vector-based.
- **reproduction/**: original supplied assets and the programmatic build scripts.

## Editing and print

SVG pages are 594 × 420 mm. Text remains live and each state's boundary and growth curve is separately editable inside a named group. Source coordinates remain in the path data; transforms place and uniformly scale them. The clipped detail groups retain the complete original curves beneath their clipping windows.

Fonts: Nimbus Roman (regular and italic) and DejaVu Sans. All fonts used in the PDFs are embedded subsets. Install these fonts to preserve the editable SVG's typography consistently across applications.

PDFs have a 594 × 420 mm TrimBox and 3 mm of bleed on every side, producing a 600 × 426 mm media size. Print using the TrimBox at 100%. Artwork uses restrained RGB blue-grey and warm off-white. These files are not certified PDF/X; no printer-specific CMYK profile has been imposed. The solid vector background replaces the reference's raster paper texture to keep the artwork fully vector.

## Geometry fidelity

Each AI export contains one identical square boundary and one closed growth curve with 1,500 cubic Bézier segments. The Rhino AI commands m, L, c, C and s are transcribed directly into SVG M, L, C and Z commands. Numeric coordinate strings and all Bézier control points are retained verbatim. The upper-case AI C is a cubic segment and is retained, not omitted. Styling and placement are the only changes.

The main SVG retains all 10,500 cubic segments across the seven exports. The mechanics SVG reuses three complete curves behind clips and a fourth original curve in the crop locator. PDF preflight confirms 10,500 and 6,000 cubic commands respectively, with zero raster images. SVG comparisons verify every source-derived path against its transcription. No curve was traced, simplified, fitted, interpolated between states or AI-generated.

## Sequence and measurement interpretation

The seven states follow the supplied source filenames, from Step0 to Stage06. They are state indices, not iteration counts or equally spaced time samples. The square boundary is identical in every file, so a common scale and orientation are supported directly by the vectors. Continuous-run provenance, elapsed time and unchanged simulation settings cannot be independently established from these exports; no such quantitative claims are added.

Relative length L/L₀ is calculated from the exported cubic curves using 32-point Gauss–Legendre integration of each segment's derivative, including any closing segment. Ratios are independent of a common drawing-unit scale. The CSV retains lengths in export coordinates, not assumed Rhino model units. Export segment counts are representation counts, not a new measurement of solver particle counts.

State 05 has L/L₀ ≈ 24.39; state 06 has L/L₀ ≈ 19.77, a reduction of approximately 18.94%. The source names state that 06 was recorded after a longer run. The artwork therefore describes continued relaxation and redistribution rather than claiming monotonically increasing curve length. The final filename's intent to even out density is not presented as a measured uniformity result. No coverage percentage, minimum clearance, absence of intersections, convergence or runtime performance is inferred.

## Mechanics verified from the Grasshopper definition

The .gh archive was decompressed and its serialized component descriptions and embedded Python code inspected. The definition was not executed in Rhino/Kangaroo in this environment.

- **Seed preparation:** the host-derived seed script produces a closed curve. Rebuild is followed by the mapping script, which uses PullToBrepFace before the curve enters Divide Curve and the segment chain.
- **Discretization:** Divide Curve, Shift List and Line establish the initial chain. The growth chain uses these original segments; it does not implement per-iteration vertex insertion.
- **Length(Line):** target-length goals provide expansion where targets exceed current segment length.
- **Angle:** paired line segments and bending strengths influence fold shape.
- **Collider:** the component describes collisions between thickened line segments and spheres. Local radii and collision strength affect its response. This is a solver goal, not evidence that the exported smooth curve has guaranteed clearance.
- **OnMesh:** constrains points to the host mesh. This does not independently certify every point of the reconstructed NURBS curve lies on the exact host surface.
- **BouncySolver:** combines the goals with momentum and repeated internal iterations. Damping and iterations-per-update are controls, not elapsed-time measurements.
- **Output:** the definition includes the periodic NURBS reconstruction labelled FINAL smooth closed curve. The supplied AI curves are used as the artwork, rather than reconstructing them anew from solver points.
- **Density field:** code samples initial segment midpoints. It supplies Radii, Lengths and BendStrengths, with field values travelling with those segments. It is not a live world-space attraction force. The mechanics panel documents this capability without asserting a verified numerical density configuration for each snapshot.

## Reproduction

Dependencies: Python 3 with NumPy, lxml, pypdf, ReportLab and PyMuPDF; Inkscape; the fonts above.

From the reproduction directory:

1. `python work/inspect_vectors.py`
2. `python work/metrics.py`
3. `python work/build_package.py`
4. `inkscape output/Growth_Evolution.svg --export-filename=output/Growth_Evolution.pdf`
5. `inkscape output/Growth_Mechanics.svg --export-filename=output/Growth_Mechanics.pdf`
6. `python work/finish.py`

The final script adds print bleed, combines the PDFs, generates previews and checks that all expected cubic commands survive PDF export.
