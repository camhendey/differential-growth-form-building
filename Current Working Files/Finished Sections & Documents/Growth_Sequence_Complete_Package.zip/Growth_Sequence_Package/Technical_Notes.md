# Differential growth: mechanics, analogy and implementation

This extension adds three editable A2 technical boards to the original two-board growth sequence. The original project curves remain unchanged. New line-and-node diagrams are explanatory schematics, not reconstructed project geometry, recorded force data or simulations of living tissue.

## Reading the section

1. **Growth Evolution:** observed geometric progression from the seven supplied vector states.
2. **Growth Mechanics:** matched source details and the actual component workflow.
3. **Growth Physical Mechanics:** extension, bending, contact and host confinement as competing requirements.
4. **Growth Natural Principles:** growth mismatch in connected tissue, its relationship to buckling, and a precise mapping to this design model.
5. **Growth Control Translation:** the implemented field-to-parameter equations, a reproducible numerical example and the boundary between control inputs and measured outcomes.

The first four boards support a visual project narrative. The fifth is a technical appendix for closer inspection. Together they provide inspectable evidence of translating a natural principle into a computational representation, separating controls, and evaluating claims. They do not establish individual authorship of inherited code or components; contribution statements should follow the actual project history.

## D1. Project evidence

Definition: `Kangaroo_Refined_Mapped_Seed(1).gh`.

SHA-256: `1d0316fb822eaf62cec887da254b20bda3d67b2a80485d678e6bdc0dfe27b078`.

The definition's serialized component descriptions and embedded Python source were inspected. The file was not executed in Rhino/Kangaroo during this documentation task. The archive in the current presentation package matches the inspected definition byte for byte.

Verified elements: initial curve subdivision; Length(Line); Angle; Collider for thickened segments and spheres; OnMesh; BouncySolver; periodic smooth-curve output; the field script producing Radii, Lengths and BendStrengths. The fixed segment chain is not a model of cells dividing or of per-iteration vertex insertion. The representation has fixed initial connectivity while the solver relaxes its geometry.

The field samples initial segment midpoints. Point and curve attractors contribute through nearest distance. An axis gradient is mixed with this influence, bounded, and cyclically smoothed before conversion to parameter multipliers. These assignments travel with the segment indices. The full-host field preview therefore represents the input field, not a guarantee that the final curve's density is the same function of its current world-space position.

## Geometric mechanics

- **Extension:** for current segment length ℓ and target ℓ*, an error ℓ − ℓ* describes the mismatch. A target greater than the current length favours expansion; a shorter target favours contraction. The documented equation is a geometric residual, not the internal Kangaroo force or update equation.
- **Bending:** an angle goal biases adjacent segments toward a target angle. Its weight controls its influence relative to other goals. Reduced bend strength can permit tighter turns, but no exact loop diameter follows from the weight alone.
- **Collision:** for two non-exempt thickened segments, δ = max(0, rᵢ + rⱼ − dᵢⱼ) describes overlap of their radius envelopes, with dᵢⱼ their closest centreline distance. The board illustrates overlapping envelopes. This is a conceptual contact residual, not a claim about the exact implementation, pair exclusions or numerical tolerance of Collider.
- **Host constraint:** dist(p, M) expresses a particle's distance from the supplied host mesh. Keeping solver particles near this mesh does not certify that every point of the final smooth curve is on the exact original CAD surface or within a trimmed boundary.
- **Relaxation:** these goals act together. Momentum, damping, relative strengths, resolution and solver update count affect the path toward a configuration. Numerical updates are not measured biological time. No physical units for energy, force, stiffness or growth rate have been calibrated here.

Folding is a mechanical interpretation consistent with competing length, bending, confinement and contact goals. The exports alone cannot isolate how much each goal caused a particular fold. The diagrams should not be described as measured stress plots or force balances.

## Exact field-to-parameter mapping

Using the notation on board 05:

```text
clamp(x, a, b) = max(a, min(b, x))
D_i = C^(blend * f_i)
r_i / r_0 = clamp(D_i^(-spacing_contrast), 0.3, 3.0)
l_i_target / l_0 = clamp(D_i^(growth_boost), 0.65, 1.5)
Dhat_j = sqrt(D_i * D_paired)
B_j / B_0 = clamp(Dhat_j^(-2 * loop_contrast), 0.12, 6.0)
```

Here `f_i` is the bounded, smoothed initial field sample, not the raw distance to the attractor. `D_paired` comes from the actual shifted segment input to the Angle component, including its own cyclic field smoothing. `l_0` in these equations is the base target-length control; it is not the measured length of the entire seed curve, denoted L₀ in the evolution measurements.

The response chart uses an illustrative equal-density neighbourhood with spacing_contrast = 1, loop_contrast = 1 and growth_boost = 0.25. It evaluates the equations, not a new Grasshopper run. None of the clamps are active over D = 0.5 to 2 in this example.

| D | Radius multiplier | Target-length multiplier | Bend-strength multiplier |
|---|---:|---:|---:|
| 0.5 | 2 | 0.8408964153 | 4 |
| 1 | 1 | 1 | 1 |
| 2 | 0.5 | 1.1892071150 | 0.25 |

With growth_boost = 0, the target-length multiplier is 1 for every D. The displayed three-parameter response must not be reported as the settings used for the seven snapshots; their complete run metadata was not supplied.

## The natural analogy

Unequal preferred growth in connected tissue creates a compatibility problem. In thin tissue, deformation can accommodate that mismatch. Wavy leaf and petal margins are relevant natural examples [R1, R2]. R1 combines plant measurements and finite-element analysis and reproduces growth-associated shape classes in hydrogels. This supports a biological and material-design analogy, not a validation of the present curve solver.

The common principle is incompatible preferred dimensions resolved through deformation. The representations differ: this project is a connected curve on a prescribed host; a leaf or petal is an extended tissue with material properties and potentially out-of-plane deformation. The project does not implement cellular regulation, tissue production, a growing surface metric, calibrated elastic tissue properties, or a prediction of a species-specific form. Density here is a design multiplier, not measured cell density or biological growth strain.

The leaf-strip diagram is original and conceptual. It is not copied from a scientific figure, a geometric reconstruction of a leaf, or a computed elastic solution.

## Evidence and validation boundary

| Claim | Status | Evidence or required test |
|---|---|---|
| All seven curves share the same boundary | Verified from exports | Identical source boundary path strings |
| Original exported curves are preserved in presentation | Verified | Exact SVG path-string comparisons; no image elements |
| Density drives bounded radius, length and bending assignments | Verified from code | Embedded script equations above |
| Attractors exert a direct live pulling force | Not implemented in this field control | Initial parameter sampling, not live point-force application |
| State 06 has less exported length than state 05 | Verified geometrically | 32-point quadrature of cubic Béziers; about 18.94% shorter |
| Final density is more uniform than state 05 | Not measured | Equal-cell spatial length-density comparison required |
| Exported smooth curves have guaranteed collision clearance | Not established | Closest-distance and intersection tests on the final curve required |
| The solver has converged | Not established | Goal residuals and displacement history required |
| 3D output conforms within a known tolerance | Not established | Curve-to-host distance measurement required |
| Results are independent of discretization | Not established | Controlled reruns at different initial division counts required |
| The simulation predicts biological growth | Not claimed | A different model and physical validation would be required |

## Targeted future tests, specified but not performed

These tests are included as an engineering evaluation framework, not results:

1. **Goal residuals:** record segment-length residuals, angle residuals, non-neighbour collision penetration and particle-to-mesh distance across updates. Track maximum displacement as well; a low residual in one goal does not prove global convergence.
2. **Output clearance:** evaluate minimum distance between non-adjacent portions of the final smooth curve, with an explicit arc-length neighbour exclusion and numerical tolerance. Test self-intersections separately. A particle-only test is insufficient.
3. **Host deviation:** sample the smooth curve adaptively, report maximum and RMS distance to the intended host, and test the trimmed domain where relevant. State the mesh and CAD tolerances.
4. **Spatial density:** partition the common square into identical cells, integrate curve length within each cell, and compare the observed distribution with the intended field. Account for boundary cells and distinguish current-space density from initial segment assignments.
5. **Discretization sensitivity:** run the same host, seed and controls at multiple division counts. Compare output statistics and stability, while acknowledging that exact folds may differ.

## References

- **[R1]** Huang, C., Wang, Z., Quinn, D., Suresh, S. and Hsia, K. J. (2018). *Differential growth and shape formation in plant organs*. PNAS 115(49), 12359–12364. https://doi.org/10.1073/pnas.1811296115. Open article: https://pmc.ncbi.nlm.nih.gov/articles/PMC6298086/.
- **[R2]** Sharon, E., Roman, B., Marder, M., Shin, G.-S. and Swinney, H. L. (2002). *Buckling cascades in free sheets*. Nature 419, 579. https://doi.org/10.1038/419579a.
- **[D1]** Supplied Grasshopper definition and seven Rhino AI exports, preserved in `reproduction/upload/` within the complete package. The implementation evidence is this project file, not a generic differential-growth algorithm.

## Editing and reproduction

All new boards use live text, vector schematics and the established warm off-white / blue-grey design system, with a restrained copper accent identifying mechanical action. Original project curves are kept in named groups and clipped without altering their source paths.

SVG artboards are 594 × 420 mm. PDFs use A2 TrimBoxes with 3 mm bleed on every side and embedded font subsets. Artwork is RGB vector output, not printer-profiled PDF/X. Preview PNGs are review aids only.

Dependencies: Python with numpy, lxml, pypdf and PyMuPDF; Inkscape; Nimbus Roman and DejaVu Sans fonts. From `reproduction/`, follow the original README to produce vectors and metrics, run `python work/extend_package.py`, export its three SVGs through Inkscape, and run `python work/finish_extension.py`. The finished package contains the complete assets and build scripts.
